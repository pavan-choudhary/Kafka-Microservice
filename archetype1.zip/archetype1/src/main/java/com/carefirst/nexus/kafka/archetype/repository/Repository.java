package com.carefirst.nexus.kafka.archetype.repository;

public interface Repository {

}
