package com.carefirst.nexus.kafka.archetype.entity;

@javax.persistence.Entity
public class Entity {

}
