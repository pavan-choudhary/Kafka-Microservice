package com.carefirst.nexus.kafka.archetype.service;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

@org.springframework.stereotype.Service
public class Service {
	@KafkaListener(topics = "topic", containerFactory = "kafkaListenerContainerFactory")
	public void consume(@Payload Object payload, @Headers MessageChannel head, Acknowledgment ack) {
		try {
			// bussines logic
			ack.acknowledge();
		} catch (Exception e) {
			System.err.println(e.getMessage());
			System.out.println("going to scheduler ");
			// this.kafkaTemplate.send("error", contact.getEntity_type().toString(),
			// contact);
			ack.acknowledge();
		}
	}
}
