package com.publisher.publisher.repository;

import java.io.FileReader;
import java.io.IOException;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Repository;

import com.publisher.publisher.model.Patient;
import com.publisher.publisher.utility.JsonToPatient;

@Repository
public class PublishRepositoryImpl implements PublishRepository {

	JsonToPatient jsonTOPatient = new JsonToPatient();

	public Patient readFile(Integer i) {
		Object readFile;
		try {
			readFile = new JSONParser().parse(new FileReader("./json/" + i + ".json"));
			JSONObject readFileJson = (JSONObject) readFile;
			return jsonTOPatient.convertTOPatient(readFileJson);
		} catch (IOException | ParseException e) {
			e.printStackTrace();
			return new Patient();
		}

	}
}
