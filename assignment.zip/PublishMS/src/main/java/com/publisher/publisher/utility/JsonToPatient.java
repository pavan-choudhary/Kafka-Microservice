package com.publisher.publisher.utility;

import org.json.simple.JSONObject;

import com.publisher.publisher.model.Patient;

public class JsonToPatient {
	public Patient convertTOPatient(JSONObject readFileJson) {
		try {
			Long id=(Long)readFileJson.get("Id");
			Long age= (Long)readFileJson.get("age");
			Patient patient = new Patient(
					id.intValue(),
					(String)readFileJson.get("firstName"),
					(String)readFileJson.get("lastName"),
					(String)readFileJson.get("gender"),
					age.intValue());
			return patient;
		} catch (Exception e) {
			return new Patient();
		}
	}
}
