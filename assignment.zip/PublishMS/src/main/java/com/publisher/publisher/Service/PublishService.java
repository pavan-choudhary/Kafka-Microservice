package com.publisher.publisher.Service;

public interface PublishService {
	public String sendPatient();
}
