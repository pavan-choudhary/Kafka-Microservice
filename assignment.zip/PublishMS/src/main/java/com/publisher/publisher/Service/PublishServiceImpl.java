package com.publisher.publisher.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import com.publisher.publisher.model.Patient;
import com.publisher.publisher.repository.PublishRepository;

@Service
public class PublishServiceImpl implements PublishService {
	@Autowired
	RestTemplate restTemplate;

	@Autowired
	PublishRepository publishRepo;

	public String sendPatient() {
		System.out.println("Publishing started");

		for (int i = 0; i < 4; i++) {
			Patient patient = publishRepo.readFile(i);
			if (patient == null)
				patient = new Patient();
			String resp = restTemplate.postForObject("http://localhost:8201/publish", patient, String.class);
			System.out.println(resp);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		return "Success";
	}
}
