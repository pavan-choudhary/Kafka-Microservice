package com.publisher.publisher.repository;

import com.publisher.publisher.model.Patient;

public interface PublishRepository {
	public Patient readFile(Integer i);
}
