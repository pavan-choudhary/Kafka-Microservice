package com.Kafka.server.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.Kafka.server.Service.KafkaService;
import com.Kafka.server.model.Patient;

@RestController
public class KafkaController {

	@Autowired
	KafkaService kservice;

	@PostMapping(value = "/publish")
	public String sendMessageToKafkaTopic(@RequestBody Patient paramPatient) {
		return kservice.sendPatient(paramPatient);
	}
}
