package com.Kafka.server.streamkafka;

import org.springframework.cloud.stream.annotation.Input;
import org.springframework.cloud.stream.annotation.Output;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.SubscribableChannel;

public interface PatientStream {
	String INPUT = "patient-in";
	String OUTPUT = "patient-out";

	@Input(INPUT)
	SubscribableChannel inBoundPatient();

	@Output(OUTPUT)
	MessageChannel outBoundPatient();
}