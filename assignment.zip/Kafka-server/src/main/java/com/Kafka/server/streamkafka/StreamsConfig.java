package com.Kafka.server.streamkafka;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(PatientStream.class)
public class StreamsConfig {

}
