package com.Kafka.server.Service;

import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Service;

import com.Kafka.server.model.Patient;
import com.Kafka.server.streamkafka.PatientStream;

@Service
public class KafkaServiceImpl implements KafkaService {
	private final PatientStream patientStream;

	public KafkaServiceImpl(PatientStream patientStream) {
		this.patientStream = patientStream;
	}

	public String sendPatient(Patient patient) {
		MessageChannel messageChannel = patientStream.outBoundPatient();
		messageChannel.send(MessageBuilder.withPayload(patient)
				// .setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON)
				.build());
		return "patient sent";
	}
}
