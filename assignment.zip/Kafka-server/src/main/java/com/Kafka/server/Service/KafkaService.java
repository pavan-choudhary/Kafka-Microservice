package com.Kafka.server.Service;

import com.Kafka.server.model.Patient;

public interface KafkaService {
	public String sendPatient(Patient patient);
}
