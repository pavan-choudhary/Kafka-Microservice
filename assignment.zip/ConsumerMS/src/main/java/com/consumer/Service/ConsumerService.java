package com.consumer.Service;

public interface ConsumerService {

}
