package com.consumer.Service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import com.consumer.Dao.ConsumerDao;
import com.consumer.model.Account;
import com.consumer.model.Patient;
import com.consumer.streamkafka.PatientStream;

@Transactional
@Service
public class ConsumerServiceImpl implements ConsumerService {

	@Autowired
	ConsumerDao consumerDao;

	@StreamListener(PatientStream.INPUT)
	public void patientDataListner(@Payload Patient patient) {
		Account patientAccount = consumerDao.getAccountDetails(patient.getId());
		consumerDao.insertPatientAndAccount(patient, patientAccount);
		System.out.println(patient.getFirstName() + "\t" + patientAccount.getSalary());

	}
}
