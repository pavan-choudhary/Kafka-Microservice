package com.consumer.utility;

import com.consumer.Entity.PatientAndAccount;
import com.consumer.model.Account;
import com.consumer.model.Patient;

public class CombinePatientAccount {
	public PatientAndAccount combinePatientAccount(Patient patient, Account account) {
		PatientAndAccount allData = new PatientAndAccount();
		allData.setId(patient.getId());
		allData.setFirstName(patient.getFirstName());
		allData.setLastName(patient.getLastName());
		allData.setGender(patient.getGender());
		allData.setAge(patient.getAge());

		allData.setSalary(account.getSalary());
		allData.setLocation(account.getLocation());
		return allData;
	}
}
