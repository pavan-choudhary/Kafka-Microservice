package com.consumer.streamkafka;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(PatientStream.class)
public class StreamsConfig {

}
