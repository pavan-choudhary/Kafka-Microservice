package com.consumer.Dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.web.client.RestTemplate;

import com.consumer.Entity.PatientAndAccount;
import com.consumer.model.Account;
import com.consumer.model.Patient;
import com.consumer.utility.CombinePatientAccount;

@Repository
public class ConsumerDaoImpl implements ConsumerDao {
	@PersistenceContext
	EntityManager entityManager;

	@Autowired
	RestTemplate restTemplate;

	CombinePatientAccount combinePatientAccount = new CombinePatientAccount();

	@Override
	public Account getAccountDetails(Integer patientId) {
		return restTemplate.getForObject("http://localhost:8204/getPatientDetails/" + patientId, Account.class);
	}

	@Override
	public void insertPatientAndAccount(Patient patient, Account patientAccount) {
		PatientAndAccount allData = combinePatientAccount.combinePatientAccount(patient, patientAccount);
		entityManager.persist(allData);
	}

};