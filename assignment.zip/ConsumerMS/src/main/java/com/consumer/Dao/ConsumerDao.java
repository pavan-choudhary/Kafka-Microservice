package com.consumer.Dao;

import com.consumer.model.Account;
import com.consumer.model.Patient;

public interface ConsumerDao {
	public Account getAccountDetails(Integer patientId);
	public void insertPatientAndAccount(Patient patient, Account patientAccount);
}
