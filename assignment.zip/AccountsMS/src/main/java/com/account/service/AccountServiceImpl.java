package com.account.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.account.Repository.AccountRepository;
import com.account.entity.Account;

@Service
public class AccountServiceImpl implements AccountService {
	@Autowired
	private AccountRepository accountRepo;

	public Account getPatient(Integer patientId) {
		Account account = accountRepo.findById(patientId);
		if (account == null)
			return new Account();
		else
			return account;
	}
}
