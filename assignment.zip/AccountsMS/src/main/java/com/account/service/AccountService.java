package com.account.service;

import com.account.entity.Account;

public interface AccountService {
	public Account getPatient(Integer patientId);
}
