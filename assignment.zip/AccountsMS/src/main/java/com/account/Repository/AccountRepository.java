package com.account.Repository;

import com.account.entity.Account;

public interface AccountRepository{
	Account findById(Integer Id);
}
