package com.account.Repository;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.account.entity.Account;

@Repository
public class AccountRepositoryImpl implements AccountRepository {

	@Autowired
	EntityManager entityManager;

	@Override
	public Account findById(Integer patientId) {
		return entityManager.find(Account.class, patientId);
	}

}
