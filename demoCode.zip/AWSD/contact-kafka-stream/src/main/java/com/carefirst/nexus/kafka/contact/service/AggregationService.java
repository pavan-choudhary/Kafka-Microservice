package com.carefirst.nexus.kafka.contact.service;

import java.sql.Timestamp;
import java.util.Collections;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.CountDownLatch;

import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.Topology;
import org.apache.kafka.streams.errors.LogAndContinueExceptionHandler;
import org.apache.kafka.streams.kstream.Consumed;
import org.apache.kafka.streams.kstream.Produced;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.support.serializer.JsonSerde;
import org.springframework.stereotype.Service;

import com.carefirst.nexus.kafka.contact.Dao.EntTypeDao;
import com.carefirst.nexus.kafka.contact.Dao.MemberRepository;
import com.carefirst.nexus.kafka.contact.Dao.SubrRepository;
import com.carefirst.nexus.kafka.contact.config.Config;
import com.carefirst.nexus.kafka.contact.entity.MemberEntity;
import com.carefirst.nexus.kafka.contact.model.Contact;
import com.carefirst.nexus.kafka.contact.model.ContactPayload;
import com.carefirst.nexus.kafka.contact.model.Email;
import com.carefirst.nexus.kafka.contact.model.Phone;

@Service
public class AggregationService {
	Logger logger = Logger.getLogger(AggregationService.class);

	@Autowired
	private MemberRepository repo;

	@Autowired
	private SubrRepository subrRepo;
	
	@Autowired
	private EntTypeDao entDao;

	@Autowired
	private Config config;

	@Value("${output.topic}")
	private String contactTopic;
	
	static final String PHONE = "Phone";
	final String EMAIL = "Email";
	
	public void getStream() {
		BasicConfigurator.configure();
		Properties props = new Properties();
		props.put(StreamsConfig.APPLICATION_ID_CONFIG, config.getGroupId());
		props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, config.getBootstrapServers());
		props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());
		props.put(StreamsConfig.DEFAULT_DESERIALIZATION_EXCEPTION_HANDLER_CLASS_CONFIG, LogAndContinueExceptionHandler.class);

		final StreamsBuilder builder = new StreamsBuilder();

		Serde<ContactPayload> payloadSerde = new JsonSerde<ContactPayload>(ContactPayload.class);
		payloadSerde.configure(Collections.emptyMap(), false);

		Serde<Email> emailSerde = new JsonSerde<Email>(Email.class);
		emailSerde.configure(Collections.emptyMap(), false);

		Serde<Phone> phoneSerde = new JsonSerde<Phone>(Phone.class);
		phoneSerde.configure(Collections.emptyMap(), false);

		builder.stream(config.getEmailTopic(), Consumed.with(Serdes.String(), emailSerde))
				.filter((key, value) -> value.getEnt_skey() != null).mapValues((value) -> {
					System.out.println(value.getEmal_addr_id());
					return setEmailContact(value);
				}).to(contactTopic, Produced.with(Serdes.String(), payloadSerde));

		// phone
		builder.stream(config.getPhoneTopic(), Consumed.with(Serdes.String(), phoneSerde))
				.filter((key, value) -> value.getEnt_skey() != null).mapValues((value) -> {
					System.out.println(value.getPhon_nbr());
					return setPhoneContact(value);
				}).to(contactTopic, Produced.with(Serdes.String(), payloadSerde));

		final Topology topology = builder.build();
		final KafkaStreams streams = new KafkaStreams(topology, props);
		final CountDownLatch latch = new CountDownLatch(1);

		// attach shutdown handler to catch control-c
		Runtime.getRuntime().addShutdownHook(new Thread("streams-shutdown-hook") {
			@Override
			public void run() {
				streams.close();
				latch.countDown();
			}
		});

		try {
			streams.start();
			latch.await();
		} catch (Throwable e) {
			System.exit(1);
		}
		System.exit(0);
	}

	private ContactPayload setPhoneContact(Phone phone) {
		ContactPayload payload=new ContactPayload();
		payload.set__delete(phone.get__delete());
		Contact c = new Contact();
		Date d = new Date();
		c.setContact_type(PHONE);
		c.setContact_value(phone.getPhon_nbr());
		c.setContact_status(phone.getPhon_nbr_stus_cd());
		c.setContact_source(phone.getAud_srce_sys_cd());
		c.setStart_date(phone.getCtact_phon_nbr_beg_dt());
		c.setEnd_date(phone.getCtact_phon_nbr_end_dt());
		c.setVerification_code(phone.getPhon_nbr_stus_verfn_cd());
		c.setAudit_insrt_id("sys");
		c.setAudit_insrt_tmstp(new Timestamp(d.getTime()));
		c.setAudit_updt_id("sys");
		c.setAudit_updt_tmstp(new Timestamp(d.getTime()));
		MemberEntity member = repo.findByEntSkey(phone.getEnt_skey());
		if (member.getEnt_skey() != null) {
			System.out.println(member.getSubr_id());
			c.setEntityId(member.getSubr_id());
			String lifeId = subrRepo.findLifeIdBySubrId(member.getSubr_id());
			if (lifeId != null) {
				c.setEntity_related_id(lifeId);
			} 
			else
				logger.warn("cannot find life Id for subr_id" + member.getSubr_id());
			String entity_type = entDao.findEntTypeBySkey(phone.getEnt_skey());
			if (entity_type != null) {
				c.setEntity_type(entity_type);
			} else
				logger.warn("cannot find Entity type for ent_skey" + member.getEnt_skey());
			payload.setContact(c);
			return payload;
		} else {
			logger.warn("cannot find details");
			return null;
		}
	}

	public ContactPayload setEmailContact(Email email) {
		ContactPayload payload=new ContactPayload();
		payload.set__delete(email.get__delete());
		Contact c = new Contact();
		Date d = new Date();
		c.setContact_type(EMAIL);
		c.setContact_value(email.getEmal_addr_id());
		c.setContact_source(email.getAud_srce_sys_cd());
		c.setContact_status(email.getEmal_addr_stus_cd());
		c.setStart_date(new Timestamp(d.getTime()));
		c.setEnd_date(email.getCtact_emal_addr_end_dt());
		c.setVerification_code(email.getEmal_addr_stus_verfn_cd());
		c.setAudit_insrt_id("sys");
		c.setAudit_insrt_tmstp(new Timestamp(d.getTime()));
		c.setAudit_updt_id("sys");
		c.setAudit_updt_tmstp(new Timestamp(d.getTime()));
		MemberEntity member = repo.findByEntSkey(email.getEnt_skey());
		if (member.getEnt_skey() != null) {
			System.out.println(member.getSubr_id());
			c.setEntityId(member.getSubr_id());
			String lifeId = subrRepo.findLifeIdBySubrId(member.getSubr_id());
			if (lifeId != null) {
				c.setEntity_related_id(lifeId);
			} else
				logger.warn("cannot find life Id for subr_id" + member.getSubr_id());
			String entity_type = entDao.findEntTypeBySkey(email.getEnt_skey());
			if (entity_type != null) {
				c.setEntity_type(entity_type);
			} else
				logger.warn("cannot find Entity type for ent_skey" + member.getEnt_skey());
			logger.info("contact returning" + c.toString());
			payload.setContact(c);
			return payload;
		} else {
			logger.warn("cannot find details");
			return null;
		}
	}

}
