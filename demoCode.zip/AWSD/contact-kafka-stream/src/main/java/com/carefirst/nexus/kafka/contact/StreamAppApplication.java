package com.carefirst.nexus.kafka.contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.carefirst.nexus.kafka.contact.service.AggregationService;

@SpringBootApplication
public class StreamAppApplication implements CommandLineRunner {
	@Autowired
	AggregationService serv;
	
	public static void main(String[] args) {
		SpringApplication.run(StreamAppApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		serv.getStream();
	}

}
