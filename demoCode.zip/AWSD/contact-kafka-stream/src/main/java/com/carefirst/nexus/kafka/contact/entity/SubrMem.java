package com.carefirst.nexus.kafka.contact.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "subr_memb", catalog = "elig" ,schema = "elig")
public class SubrMem {
	@Id
	private Integer subr_memb_skey;
	private String memb_life_id;
	private String subrId;

	public String getMemb_life_id() {
		return memb_life_id;
	}
}
