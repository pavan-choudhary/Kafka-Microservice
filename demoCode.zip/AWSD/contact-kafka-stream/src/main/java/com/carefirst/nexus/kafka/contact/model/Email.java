package com.carefirst.nexus.kafka.contact.model;

import java.sql.Timestamp;

import lombok.Getter;

@Getter
public class Email {
	private Integer ctact_emal_addr_skey;
	private Integer memb_skey;
	private Timestamp ctact_emal_addr_beg_dt;
	private Timestamp ctact_emal_addr_end_dt;
	private String emal_addr_id;
	private String emal_addr_stus_cd;
	private String aud_srce_sys_cd;
	private String emal_addr_stus_verfn_cd;
	private Integer ent_skey;
	private Boolean __delete;

}
