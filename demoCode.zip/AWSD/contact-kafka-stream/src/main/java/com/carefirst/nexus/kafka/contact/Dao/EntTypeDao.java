package com.carefirst.nexus.kafka.contact.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carefirst.nexus.kafka.contact.entity.EntityType;

public interface EntTypeDao extends JpaRepository<EntityType, Integer> {
	@Query(nativeQuery = true, value= "SELECT ent.ent_typ_cd FROM cidb.ctact_ent ent where ent.ent_skey = :id")
	String findEntTypeBySkey(@Param("id") Integer id);
}
