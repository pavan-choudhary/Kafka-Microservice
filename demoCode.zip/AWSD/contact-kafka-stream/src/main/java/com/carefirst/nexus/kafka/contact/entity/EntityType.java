package com.carefirst.nexus.kafka.contact.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CTACT_ENT" ,schema="cidb")
public class EntityType {
	@Id
	private Integer ent_skey;
	private String ent_typ_cd;
}
