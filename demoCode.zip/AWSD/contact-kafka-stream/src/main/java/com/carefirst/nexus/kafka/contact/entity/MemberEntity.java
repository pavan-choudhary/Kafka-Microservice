package com.carefirst.nexus.kafka.contact.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "MEMB" , catalog = "cidb" ,schema = "cidb")
@Entity
public class MemberEntity {
	@Id
	private Integer memb_skey;
	private String subr_id;
	private Integer entSkey;

	public Integer getEnt_skey() {
		return entSkey;
	}

	public Integer getMemb_skey() {
		return memb_skey;
	}

	public String getSubr_id() {
		return subr_id;
	}

}
