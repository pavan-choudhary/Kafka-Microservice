package com.carefirst.nexus.kafka.contact.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Contact {
	private String entityId;
	private String entity_type;
	private String entity_related_id;
	private String contact_type;
	private String contact_value;
	private String contact_status;
	private Timestamp end_date;
	private Timestamp start_date;
	private String verification_code;
	private String contact_source;
	private String audit_insrt_id;
	private Timestamp audit_insrt_tmstp;
	private String audit_updt_id;
	private Timestamp audit_updt_tmstp;
}
