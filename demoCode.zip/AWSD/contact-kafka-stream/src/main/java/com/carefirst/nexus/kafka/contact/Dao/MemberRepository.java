package com.carefirst.nexus.kafka.contact.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.carefirst.nexus.kafka.contact.entity.MemberEntity;

public interface MemberRepository extends JpaRepository<MemberEntity,Integer> {
	MemberEntity findByEntSkey(Integer ent_skey);
}
