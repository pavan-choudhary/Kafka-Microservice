package com.carefirst.nexus.kafka.contact.model;

import java.sql.Timestamp;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Phone {
	 private Integer ctact_phon_skey;
	 private String phon_nbr;
	 private Integer ent_skey;
	 private Timestamp ctact_phon_nbr_beg_dt;
	 private Timestamp ctact_phon_nbr_end_dt;
	 private String phon_nbr_stus_cd;
	 private String aud_srce_sys_cd;
	 private String phon_nbr_stus_verfn_cd;
	 private Boolean __delete;
}
