package com.carefirst.nexus.kafka.contact.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.carefirst.nexus.kafka.contact.entity.SubrMem;

public interface SubrRepository extends JpaRepository<SubrMem, Integer> {
	@Query(nativeQuery = true, value= "SELECT s.memb_life_id FROM elig.subr_memb s where s.subr_id = :id") 
    String findLifeIdBySubrId(@Param("id") String id);
}
