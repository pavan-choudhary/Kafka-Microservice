package com.carefirst.nexus.kafka.contact.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "spring.kafka.consumer")
public class Config {
	public String bootstrapServers;
	public String groupId;
	public String offsetReset;
	public String emailTopic;
	public String phoneTopic;

	public String getBootstrapServers() {
		return bootstrapServers;
	}

	public void setBootstrapServers(String bootstrapServers) {
		this.bootstrapServers = bootstrapServers;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getOffsetReset() {
		return offsetReset;
	}

	public void setOffsetReset(String offsetReset) {
		this.offsetReset = offsetReset;
	}

	public String getEmailTopic() {
		return emailTopic;
	}

	public void setEmailTopic(String emailTopic) {
		this.emailTopic = emailTopic;
	}

	public String getPhoneTopic() {
		return phoneTopic;
	}

	public void setPhoneTopic(String phoneTopic) {
		this.phoneTopic = phoneTopic;
	}

}
