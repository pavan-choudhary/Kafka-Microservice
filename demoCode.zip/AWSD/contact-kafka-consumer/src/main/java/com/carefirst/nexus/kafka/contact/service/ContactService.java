package com.carefirst.nexus.kafka.contact.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import com.carefirst.nexus.kafka.contact.Dao.ContactDao;
import com.carefirst.nexus.kafka.contact.entity.Contact;
import com.carefirst.nexus.kafka.contact.model.ContactPayload;

@Service
public class ContactService {
//	@Autowired
//	private KafkaTemplate<String, ContactEntity> kafkaTemplate;

	@Autowired
	private ContactDao contactDao;
	
	@KafkaListener(topics = "contact", containerFactory = "kafkaListenerContainerFactory")
	public void consume(@Payload ContactPayload payload,@Headers MessageChannel head, Acknowledgment ack) {
		Contact contact=payload.getContact();
		System.err.println(contact.toString() + head.toString());
		if (contact.getEntityId() != null) {
			try {
				if(payload.get__delete()==true)
				{
					Contact delete= contactDao.findByEntityId(contact.getEntityId(),contact.getContact_type());
					contactDao.delete(delete);
					System.out.println("deleted");
				}
				else {
					Contact c= contactDao.findByEntityId(contact.getEntityId(),contact.getContact_type());
					if(c==null) {	//insert
						contactDao.save(contact);
					}
					else {		//update
						contact.setContact_key(c.getContact_key());
						contactDao.save(contact);
					}
				}
				ack.acknowledge();
				
			} catch (Exception e) {
				System.err.println(e.getMessage());
				System.out.println("going to scheduler ");
				//this.kafkaTemplate.send("error", contact.getEntity_type().toString(), contact);
				ack.acknowledge();
			}
		}
	}
}
