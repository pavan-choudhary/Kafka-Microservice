package com.carefirst.nexus.kafka.contact.error;
//package com.carefirstNexus.kafka.contactConsumer.error;
//
//import java.util.HashMap;
//import java.util.Iterator;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.kafka.annotation.KafkaListener;
//import org.springframework.messaging.MessageHeaders;
//import org.springframework.messaging.handler.annotation.Headers;
//import org.springframework.messaging.handler.annotation.Payload;
//import org.springframework.scheduling.annotation.Scheduled;
//import org.springframework.stereotype.Service;
//
//import com.carefirstNexus.kafka.contactConsumer.Dao.ContactDao;
//import com.carefirstNexus.kafka.contactConsumer.entity.ContactEntity;
//
//@Service
//public class ExceptionHandle {
//	public static final Integer retries = 3;
//	public Map<ContactEntity, Integer> queue = new HashMap<ContactEntity, Integer>();
//	
//	@Autowired
//	private ContactDao contactDao;
//	
//	@KafkaListener( topics = "${error.topic}", containerFactory = "kafkaErrorListenerContainerFactory")
//	public void consume(@Payload ContactEntity payload, @Headers MessageHeaders headers) {
//		queue.put(payload, 0);
//	}
//		
//	@Scheduled(fixedRate=20000)
//	public void scheduler(){
//		Iterator<Map.Entry<ContactEntity, Integer>> it = queue.entrySet().iterator();
//		while(it.hasNext()){
//			Map.Entry<ContactEntity, Integer> entry = it.next();
//			if (entry.getValue() < retries){
//				contactDao.save(entry.getKey());
//				System.out.println("Retry: "+ entry.getValue());
//				queue.put(entry.getKey(), entry.getValue()+1);
//			}
//			else{
//				//generate alert
//				System.out.println("Alert generated for payload "+ entry.getKey().getEntity_type());
//				it.remove();
//			}
//		}
//	}
//}
