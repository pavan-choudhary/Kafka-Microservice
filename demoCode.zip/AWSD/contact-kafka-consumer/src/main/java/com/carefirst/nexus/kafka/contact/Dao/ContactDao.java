package com.carefirst.nexus.kafka.contact.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.carefirst.nexus.kafka.contact.entity.Contact;

public interface ContactDao extends JpaRepository<Contact, Integer> {
	@Query(nativeQuery = true, value= "SELECT * FROM cidb.contact c where c.entity_id = :ent_id and c.contact_type = :type") 
	public Contact findByEntityId(String ent_id, String type);
}
