package com.carefirst.nexus.kafka.contact.model;

import com.carefirst.nexus.kafka.contact.entity.Contact;

import lombok.Getter;

@Getter
public class ContactPayload {
	private Contact contact;
	private Boolean __delete;
}