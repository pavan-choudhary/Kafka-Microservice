package com.carefirst.nexus.kafka.contact.config;
//package com.carefirstNexus.kafka.contactConsumer.config;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.apache.kafka.clients.consumer.ConsumerConfig;
//import org.apache.kafka.clients.producer.ProducerConfig;
//import org.apache.kafka.common.serialization.StringDeserializer;
//import org.apache.kafka.common.serialization.StringSerializer;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.kafka.annotation.EnableKafka;
//import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
//import org.springframework.kafka.core.ConsumerFactory;
//import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
//import org.springframework.kafka.core.DefaultKafkaProducerFactory;
//import org.springframework.kafka.core.KafkaTemplate;
//import org.springframework.kafka.core.ProducerFactory;
//import org.springframework.kafka.support.serializer.JsonDeserializer;
//import org.springframework.kafka.support.serializer.JsonSerializer;
//
//import com.carefirstNexus.kafka.contactConsumer.entity.ContactEntity;
//
//@EnableKafka
//@Configuration
//public class ErrorConfig {
//		@Value("${spring.kafka.error.bootstrap-servers}")
//		private String bootstrapServers;
//
//		@Value("${spring.kafka.error.group-id}")
//		private String groupId;
//
//		@Value("${spring.kafka.error.key-deserializer}")
//		private String keySerializer;
//
//		@Value("${spring.kafka.error.auto-offset-reset}")
//		private String autoOffsetReset;
//		
//		public Map<String, Object> errorConsumerConfigs() {
//			Map<String, Object> config = new HashMap<>();
//			config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
//			config.put(ConsumerConfig.GROUP_ID_CONFIG, groupId);
//			config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, autoOffsetReset);
//			config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, keySerializer);
//			config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, new JsonDeserializer<ContactEntity>(ContactEntity.class));
//			return config;
//		}
//		@Bean
//		public ConsumerFactory<String, ContactEntity> errorConsumerFactory() {
//			return new DefaultKafkaConsumerFactory<>(errorConsumerConfigs(), new StringDeserializer(),
//					new JsonDeserializer<ContactEntity>(ContactEntity.class));
//		}
//		
//		//error consumer
//		@Bean
//		public ConcurrentKafkaListenerContainerFactory<String, ContactEntity> kafkaErrorListenerContainerFactory() {
//			ConcurrentKafkaListenerContainerFactory<String, ContactEntity> factory = new ConcurrentKafkaListenerContainerFactory<>();
//			factory.setConsumerFactory(errorConsumerFactory());
//			return factory;
//			
//		}
//		
//	//error Producer config
//		@Bean
//		public ProducerFactory<String, ContactEntity> errorProducerFactory() {
//			Map<String, Object> producerProps = new HashMap<>();
//			producerProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
//			producerProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
//			producerProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
//			return new DefaultKafkaProducerFactory<>(producerProps);
//		}
//
//		@Bean
//		public KafkaTemplate<String, ContactEntity> kafkaTemplate() {
//			return new KafkaTemplate<>(errorProducerFactory());
//		}
//		
//
//}