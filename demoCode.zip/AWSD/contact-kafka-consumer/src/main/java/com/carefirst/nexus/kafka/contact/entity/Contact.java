package com.carefirst.nexus.kafka.contact.entity;

import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Table(name="contact" ,schema = "cidb") //change schema name and table name
@Getter
@Setter
@ToString
public class Contact {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer contact_key; //set
	private String entity_type; //set
	private String entityId;
	private String entity_related_id;
	private String contact_type;
	private String contact_value;
	private String contact_status; //set
	private Timestamp end_date;
	private Timestamp start_date;
	private String verification_code;
	private String contact_source;
	private String audit_insrt_id;
	private Timestamp audit_insrt_tmstp;
	private String audit_updt_id;
	private Timestamp audit_updt_tmstp;
	
	
}