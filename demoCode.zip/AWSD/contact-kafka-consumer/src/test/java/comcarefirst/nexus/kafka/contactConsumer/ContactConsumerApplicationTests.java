package comcarefirst.nexus.kafka.contactConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
